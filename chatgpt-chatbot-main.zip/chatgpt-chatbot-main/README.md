# chatgpt-chatbot
Project for Computer Network course in Semester 4, HCMUS
